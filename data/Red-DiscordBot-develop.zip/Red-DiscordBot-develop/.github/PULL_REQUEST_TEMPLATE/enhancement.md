# Enhancement request

<!--
THIS TEMPLATE IS CURRENTLY UNUSED DUE TO GITHUB LIMITATIONS!
To be used for PRs which enhance existing features
-->

#### Describe the enhancement

<!--
Describe what your changes do.
If adding commands, describe any restrictions on their usage.
  - For example, who can use the command? Where can it be used?
-->

#### Does this enhancement break existing functionality?

<!-- To check a box, replace the space between the [] with a x -->

- [ ] Yes
- [ ] No
